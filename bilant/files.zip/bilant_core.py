"""
bilant_core.py — shared logic for ANAF bilant (F10/F20) automation.

Reads the ANAF XFA PDF (template + datasets packets), derives the canonical
account -> row (rd) mapping from the template's "(ct. ...)" references, and
exposes helpers to aggregate a balanta and to write values back into the
datasets packet WITHOUT touching template/config/form packets.

No third-party accounting assumptions are hard-coded: every routing decision is
auditable and flagged.
"""
import re, io, json
import xml.etree.ElementTree as ET
import pikepdf

XFA_DATA_NS = "http://www.xfa.org/schema/xfa-data/1.0/"

# ---------- low-level XFA packet IO ----------

def read_packets(pdf_path):
    """Return dict {packet_name: bytes} and the pikepdf handle (kept open)."""
    pdf = pikepdf.open(pdf_path)
    xfa = pdf.Root.AcroForm.XFA
    packets, order = {}, []
    for i in range(0, len(xfa), 2):
        name = str(xfa[i]); order.append(name)
        packets[name] = bytes(xfa[i+1].read_bytes())
    return pdf, packets, order

def local(tag): return tag.split('}')[-1]

# ---------- template parsing: canonical account -> rd map ----------

CT_TOKEN = re.compile(r'([+\-]|\+/\-)?\s*(\d{3,4})(\*+)?')

def _row_label(subform):
    # Prefer Cell1 description; fallback to first long text/exData
    for d in subform:
        if local(d.tag) == 'draw' and d.get('name') == 'Cell1':
            return re.sub(r'\s+', ' ', ''.join(d.itertext())).strip()
    for d in subform:
        if local(d.tag) == 'draw':
            t = re.sub(r'\s+', ' ', ''.join(d.itertext())).strip()
            if len(t) > 4:
                return t
    return ''

def _row_rd(subform, name):
    toks = []
    for d in subform:
        if local(d.tag) == 'draw':
            for v in d.iter():
                if local(v.tag) == 'text' and v.text and v.text.strip():
                    toks.append(v.text.strip())
    for tk in toks:
        if re.fullmatch(r'\d+[a-zA-Z]?', tk):
            return tk
    m = re.match(r'R(\d+)$', name or '')
    return m.group(1) if m else None

def parse_template(template_bytes):
    """
    Walk the template. Return:
      sections: { section_path(str): [ {name, rd, cols, label, accounts:[{ct,sign,partial}], is_total} ] }
    section_path is the full subform ancestor path e.g. 'form1/F10L/Table1'.
    Row order within a section list mirrors template document order (canonical).
    """
    root = ET.fromstring(template_bytes)
    sections = {}

    def walk(el, path):
        tag = local(el.tag); name = el.get('name')
        newpath = path + [name] if (tag == 'subform' and name) else path
        if tag == 'subform' and name and re.match(r'R\d+$', name):
            cols = [c.get('name') for c in el.iter()
                    if local(c.tag) == 'field' and c.get('name') and c.get('name').startswith('C')]
            cols = list(dict.fromkeys(cols))
            if cols:
                label = _row_label(el)
                rd = _row_rd(el, name)
                is_total = bool(re.search(r'TOTAL|rd\.\s*\d', label, re.I))
                accounts = []
                # Parse EVERY parenthetical that carries an account ref. Handles
                # "(ct. ...)", "(din ct. ...)", "( ct. 7615)", and mixed groups
                # like "(din ct. 508+ct. 5112 + 512 + 531 ...)". Pure row-sum
                # groups like "(rd. 31 la 35)" are skipped (no "ct.<digit>").
                for pgroup in re.findall(r'\(([^)]*)\)', label):
                    if not re.search(r'ct\.?\s*[+\-]?\s*\d', pgroup, re.I):
                        continue
                    din = bool(re.search(r'din\s+ct', pgroup, re.I))
                    cut = re.search(r'ct', pgroup, re.I)
                    body = pgroup[cut.start():] if cut else pgroup
                    for m in CT_TOKEN.finditer(body):
                        sign, ct, star = m.group(1), m.group(2), m.group(3)
                        accounts.append({
                            'ct': ct,
                            'sign': -1 if sign == '-' else 1,
                            'partial': bool(star) or sign == '+/-' or din,
                        })
                key = '/'.join(p for p in path if p)  # full subform path incl leading form1(s)
                sections.setdefault(key, []).append({
                    'name': name, 'rd': rd, 'cols': cols, 'label': label,
                    'accounts': accounts, 'is_total': is_total,
                })
            return
        for c in el:
            walk(c, newpath)

    walk(root, [])
    return sections

def build_account_router(section_rows, forms=('F10L', 'F20')):
    """
    From parsed sections, build longest-prefix account router for the chosen forms.
    Returns:
      router: list of (ct_prefix, [ {form, rd, element, sign, partial, label} ]) sorted by len desc
      rows_index: { (form, element): rowdict }  for placement
    """
    # map our logical form name -> section path substring
    section_for = {}
    for path in section_rows:
        if path.endswith('/F10L/Table1'): section_for['F10'] = path
        elif path.endswith('/F20/Table1'): section_for['F20'] = path
    router_map = {}
    rows_index = {}
    for form, path in section_for.items():
        for r in section_rows[path]:
            rows_index[(form, r['name'])] = r
            for a in r['accounts']:
                router_map.setdefault(a['ct'], []).append({
                    'form': form, 'rd': r['rd'], 'element': r['name'],
                    'sign': a['sign'], 'partial': a['partial'],
                    'is_total': r['is_total'], 'label': r['label'],
                })
    router = sorted(router_map.items(), key=lambda kv: -len(kv[0]))
    return router, rows_index, section_for

def route_account(acct, router):
    """Longest-prefix match. Return list of targets (may be >1 -> ambiguous)."""
    acct = str(acct).strip()
    for ct, targets in router:
        if acct.startswith(ct):
            return ct, targets
    return None, []

# ---------- datasets writer: parallel walk (template order anchors) ----------

def _section_container(form1, section_path):
    """Strict nested navigation from the datasets <form1> root.
    Returns the element, or None if a hop is missing (e.g. F20 is not wrapped)."""
    parts = section_path.split('/')
    cur = form1
    for p in parts[1:]:  # parts[0] == 'form1' (the node we were handed)
        nxt = None
        for c in cur:
            if local(c.tag) == p:
                nxt = c; break
        if nxt is None:
            return None
        cur = nxt
    return cur

def collect_ordered_value_nodes(container):
    """
    Walk direct children of `container` in document order, grouping them into
    'rows'. A row is either:
      - a named <Rxx> wrapper containing C* fields, or
      - a run of bare <C#> siblings (positional row).
    Returns list of dicts: {name(or None), col_nodes:{colname:element}, kind}
    Spacer dataGroups (RGOL*) and header rows are skipped but recorded as gaps.
    """
    rows = []
    pending_cols = {}
    def flush():
        nonlocal pending_cols
        if pending_cols:
            rows.append({'name': None, 'cols': pending_cols, 'kind': 'positional'})
            pending_cols = {}
    for c in container:
        ln = local(c.tag)
        if ln.startswith('C') and ln[1:].isdigit():
            # bare positional column
            if ln in pending_cols:      # new row starts when a column repeats
                flush()
            pending_cols[ln] = c
            continue
        flush()
        if c.get(f'{{{XFA_DATA_NS}}}dataNode') == 'dataGroup':
            continue                    # spacer
        if re.match(r'R\d+$', ln):
            cols = {local(x.tag): x for x in c if local(x.tag).startswith('C')}
            if cols:
                rows.append({'name': ln, 'cols': cols, 'kind': 'named'})
    flush()
    return rows

def align_and_write(container, template_rows, values, period_cols, dry_run=False):
    """
    Align template_rows (canonical order, each {name, cols,...}) to datasets nodes
    (document order) and write `values`.
      values: { element_name: {colname: number} }
      period_cols: ordered list of datasets column names actually used (e.g. ['C1','C2'])
    Named datasets nodes are used as anchors: their name MUST equal the aligned
    template row name. Any mismatch => raise (refuse to guess).
    Returns report: {written:[], skipped_no_node:[], anchors_checked:int}
    """
    ds_rows = collect_ordered_value_nodes(container)
    report = {'written': [], 'skipped_no_node': [], 'anchors_checked': 0, 'alignment': []}
    # Filter template rows to those we might fill (skip pure header artifacts handled already)
    tmpl = template_rows
    if len(ds_rows) != len(tmpl):
        report['length_mismatch'] = (len(tmpl), len(ds_rows))
    n = min(len(tmpl), len(ds_rows))
    for i in range(n):
        trow, drow = tmpl[i], ds_rows[i]
        report['alignment'].append((trow['name'], drow['name']))
        if drow['name'] is not None:
            report['anchors_checked'] += 1
            if drow['name'] != trow['name']:
                raise AlignmentError(
                    f"Alignment broke at index {i}: template={trow['name']} datasets={drow['name']}")
        if trow['name'] in values:
            for col, val in values[trow['name']].items():
                node = drow['cols'].get(col)
                if node is None:
                    report['skipped_no_node'].append((trow['name'], col))
                    continue
                if not dry_run:
                    node.text = format_amount(val)
                report['written'].append((trow['name'], col, val))
    # template rows beyond datasets length
    for j in range(n, len(tmpl)):
        if tmpl[j]['name'] in values:
            report['skipped_no_node'].append((tmpl[j]['name'], 'ALL'))
    return report

class AlignmentError(RuntimeError): pass

def format_amount(val):
    """ANAF numeric cells: integer RON, no separators, no decimals."""
    try:
        return str(int(round(float(val))))
    except Exception:
        return "0"

def write_packets(pdf, packets_to_replace):
    """Replace given XFA packet streams in-place (bytes), keep all else identical."""
    xfa = pdf.Root.AcroForm.XFA
    name_to_idx = {str(xfa[i]): i+1 for i in range(0, len(xfa), 2)}
    for name, data in packets_to_replace.items():
        idx = name_to_idx[name]
        xfa[idx].write(data)
    # keep NeedsRendering so Adobe/ANAF recompute calc rows & appearances
    pdf.Root.AcroForm.NeedAppearances = True
