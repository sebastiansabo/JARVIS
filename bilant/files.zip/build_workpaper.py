#!/usr/bin/env python3
"""
build_workpaper.py  —  Stage 1 of the bilant pipeline.

Reads:  the ANAF XFA PDF (canonical account->rd map) + the balanta .xlsx
Writes: an auditable workpaper .xlsx:
        - F10 sheet (balance sheet): rd, element, label, BEGIN/END, OVERRIDE_*, flags, accounts
        - F20 sheet (P&L): rd, element, label, PRIOR/CURRENT, OVERRIDE_*, flags, accounts
        - SPLITS sheet: every account that could land on >1 row, the row chosen by
          default (sign + short-term), the alternates, and the amount — so the
          short/long-term reallocation is made in ONE place, by hand, auditable.

Each balanta account is assigned to EXACTLY ONE row (no double counting). The
choice is transparent:
  * balance side (debit->asset/receivable row, credit->liability/payable row)
  * equity 117/121 -> SOLD C if credit else SOLD D
  * short vs long maturity pairs -> SHORT-TERM (lower rd) by default, flagged
  * is_total rows are never written (the form recomputes them on render)

Usage:
  python3 build_workpaper.py --pdf BILANT.pdf --balanta BALANTA.xlsx --out workpaper.xlsx
"""
import argparse, sys, re
import openpyxl
from openpyxl.styles import Font, PatternFill
import bilant_core as bc

COLS = dict(cont=1, nume=2, SID=3, SIC=4, RPD=5, RPC=6, RCD=7, RCC=8,
            TSD=9, TSC=10, SFD=11, SFC=12, F10=13, F20=14, F30=15, F40=16)
HEADER_ROW = 4
ASSET_RD_MAX = 45  # rd <=45 are asset/prepaid rows; >=46 liabilities/equity

# account families with a genuine long-term portion -> never silently default
LONGTERM_CAPABLE = ('16', '519', '167', '162')

def load_balanta(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb['Sheet1']
    rows = []
    for r in range(HEADER_ROW + 1, ws.max_row + 1):
        cont = ws.cell(r, COLS['cont']).value
        if cont in (None, ''):
            continue
        def num(k):
            v = ws.cell(r, COLS[k]).value
            try: return float(v)
            except: return 0.0
        rows.append(dict(
            cont=str(cont).strip(), nume=ws.cell(r, COLS['nume']).value,
            SID=num('SID'), SIC=num('SIC'), RPD=num('RPD'), RPC=num('RPC'),
            RCD=num('RCD'), RCC=num('RCC'), SFD=num('SFD'), SFC=num('SFC'),
            bk_F10=ws.cell(r, COLS['F10']).value, bk_F20=ws.cell(r, COLS['F20']).value,
        ))
    return rows

def _rdnum(rd):
    try: return int(''.join(c for c in str(rd) if c.isdigit()))
    except: return 9999

def row_side_f20(rowdict):
    digits = [a['ct'][0] for a in rowdict['accounts'] if a['ct']]
    if not digits: return 'debit'
    sevens = sum(d == '7' for d in digits)
    return 'credit' if sevens * 2 >= len(digits) else 'debit'

def choose_target(form, net, targets, rows_index):
    """Pick ONE target row for this account. Returns (chosen, alternates, flags)."""
    flags = set()
    cand = [t for t in targets if not t['is_total']]
    if not cand:
        cand = targets
    if len(cand) == 1:
        return cand[0], [], flags

    if form == 'F10':
        # equity reported result: SOLD C (credit) vs SOLD D (debit)
        soldc = [t for t in cand if re.search(r'SOLD\s*C', t['label'], re.I)]
        soldd = [t for t in cand if re.search(r'SOLD\s*D', t['label'], re.I)]
        if soldc or soldd:
            chosen = (soldc[0] if net <= 0 else soldd[0]) if (soldc and soldd) \
                     else (soldc or soldd)[0]
            alt = [t for t in cand if t is not chosen]
            flags.add('SIGN-ROUTED')
            return chosen, alt, flags
        # asset vs liability by balance side
        assets = [t for t in cand if _rdnum(t['rd']) <= ASSET_RD_MAX]
        liabs  = [t for t in cand if _rdnum(t['rd']) >  ASSET_RD_MAX]
        group = assets if net > 0 else liabs
        if not group:
            group = cand
        # short-term default = lowest rd in the chosen group
        group_sorted = sorted(group, key=lambda t: _rdnum(t['rd']))
        chosen = group_sorted[0]
        alt = [t for t in cand if t is not chosen]
        if len(group_sorted) > 1:
            flags.add('SPLIT-DEFAULTED')  # short vs long term picked short
        if assets and liabs:
            flags.add('SIGN-ROUTED')
        return chosen, alt, flags
    else:
        # F20: default to lowest rd non-total; flag for review
        cand_sorted = sorted(cand, key=lambda t: _rdnum(t['rd']))
        chosen = cand_sorted[0]
        flags.add('F20-MULTI')
        return chosen, [t for t in cand if t is not chosen], flags

def aggregate(balanta, secs, router, rows_index, section_for):
    acc, unrouted, splits = {}, [], []
    for b in balanta:
        ct, targets = bc.route_account(b['cont'], router)
        if not targets:
            if any(abs(b[k]) > 0.5 for k in ('SFD', 'SFC', 'RCD', 'RCC')):
                unrouted.append(b)
            continue
        form = targets[0]['form']
        net = b['SFD'] - b['SFC']
        chosen, alternates, cflags = choose_target(form, net, targets, rows_index)
        key = (chosen['form'], chosen['element'])
        d = acc.setdefault(key, dict(begin=0.0, end=0.0, prior=0.0, current=0.0,
                                     accounts=[], flags=set(),
                                     rd=chosen['rd'], label=chosen['label'],
                                     is_total=chosen['is_total']))
        s = chosen['sign']
        if form == 'F10':
            # Use the account's RAW signed balance (debit-positive). Contra
            # accounts (281x amort., 29x prov., 169, 491...) carry a natural
            # credit balance => (SFD-SFC) already negative => they subtract.
            # The label +/- signs are documentation, NOT a second sign flip;
            # applying them would double-count contra and unbalance the sheet.
            # Summing raw (SFD-SFC) is self-balancing because the TB ties.
            d['begin'] += (b['SID'] - b['SIC'])
            d['end']   += (b['SFD'] - b['SFC'])
        else:
            side = row_side_f20(rows_index[(chosen['form'], chosen['element'])])
            if side == 'credit':
                d['prior']   += s * (b['RPC'] - b['RPD'])
                d['current'] += s * (b['RCC'] - b['RCD'])
            else:
                d['prior']   += s * (b['RPD'] - b['RPC'])
                d['current'] += s * (b['RCD'] - b['RCC'])
            d['flags'].add('F20-VERIFY')
        if chosen['partial']: d['flags'].add('PARTIAL*')
        if chosen['is_total']: d['flags'].add('TOTAL-ROW')
        d['flags'] |= cflags
        d['accounts'].append((b['cont'], str(b['nume'])[:30]))
        # long-term-capable family -> hard flag on the row + split log
        if form == 'F10' and any(b['cont'].startswith(p) for p in LONGTERM_CAPABLE) \
           and abs(net) > 0.5:
            d['flags'].add('MATURITY-SPLIT?')
        if alternates and abs(net) > 0.5:
            splits.append(dict(cont=b['cont'], nume=str(b['nume'])[:34], net=net,
                               chosen=f"rd{chosen['rd']}/{chosen['element']}",
                               chosen_label=chosen['label'][:55],
                               alts='; '.join(f"rd{t['rd']}" for t in alternates),
                               flags=','.join(sorted(cflags))))
    return acc, unrouted, splits

def emit_workpaper(acc, secs, section_for, out_path, splits):
    wb = openpyxl.Workbook()
    hdr_fill = PatternFill('solid', fgColor='1F2A44'); hdr_font = Font(bold=True, color='FFFFFF')
    flag_fill = PatternFill('solid', fgColor='FFE08A'); hard_fill = PatternFill('solid', fgColor='F4A7A0')
    for form in ('F10', 'F20'):
        path = section_for[form]; ws = wb.create_sheet(form)
        if form == 'F10':
            cols = ['rd','element','label','BEGIN (01.01)','END (period)','OVERRIDE_BEGIN','OVERRIDE_END','flags','accounts']
        else:
            cols = ['rd','element','label','PRIOR (prec.)','CURRENT','OVERRIDE_PRIOR','OVERRIDE_CURRENT','flags','accounts']
        ws.append(cols)
        for c in range(1, len(cols)+1):
            ws.cell(1, c).fill = hdr_fill; ws.cell(1, c).font = hdr_font
        for r in secs[path]:
            d = acc.get((form, r['name']))
            if form == 'F10':
                v1 = d['begin'] if d else 0.0; v2 = d['end'] if d else 0.0
            else:
                v1 = d['prior'] if d else 0.0; v2 = d['current'] if d else 0.0
            flags = set(d['flags']) if d else set()
            if form == 'F10':
                # assets (rd<=ASSET_RD_MAX) should be >=0; a negative asset is a
                # real anomaly worth flagging. Pasiv rows are naturally negative
                # (credit) -> abs() is just the magnitude the form expects.
                if _rdnum(r['rd']) <= ASSET_RD_MAX and (v1 < -0.5 or v2 < -0.5):
                    flags.add('ASSET-NEGATIVE?')
                v1, v2 = abs(v1), abs(v2)
            # is_total rows: leave value blank so the form recomputes on render
            is_total = bool(r['is_total'])
            accs = '; '.join(c for c, _ in d['accounts']) if d else ''
            ws.append([r['rd'], r['name'], r['label'],
                       (None if is_total else (round(v1) if d else None)),
                       (None if is_total else (round(v2) if d else None)),
                       None, None, ','.join(sorted(flags)), accs])
            if flags:
                cell = ws.cell(ws.max_row, 8)
                cell.fill = hard_fill if 'MATURITY-SPLIT?' in flags else flag_fill
        for i, w in enumerate([6,8,60,16,16,16,16,22,46], 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
        ws.freeze_panes = 'A2'
    # SPLITS review sheet
    ws = wb.create_sheet('SPLITS')
    cols = ['account','name','net balance','assigned row (default)','assigned label','alternate rows','flags','OVERRIDE row','OVERRIDE amount']
    ws.append(cols)
    for c in range(1, len(cols)+1):
        ws.cell(1, c).fill = hdr_fill; ws.cell(1, c).font = hdr_font
    for s in sorted(splits, key=lambda x: -abs(x['net'])):
        ws.append([s['cont'], s['nume'], round(s['net']), s['chosen'], s['chosen_label'],
                   s['alts'], s['flags'], None, None])
    for i, w in enumerate([10,34,16,20,58,20,18,14,16], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    ws.freeze_panes = 'A2'
    del wb['Sheet']
    wb.save(out_path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pdf', required=True)
    ap.add_argument('--balanta', required=True)
    ap.add_argument('--out', default='bilant_workpaper.xlsx')
    a = ap.parse_args()
    pdf, packets, order = bc.read_packets(a.pdf)
    secs = bc.parse_template(packets['template'])
    router, rows_index, section_for = bc.build_account_router(secs)
    balanta = load_balanta(a.balanta)
    acc, unrouted, splits = aggregate(balanta, secs, router, rows_index, section_for)
    emit_workpaper(acc, secs, section_for, a.out, splits)
    print(f"[ok] workpaper -> {a.out}")
    print(f"     accounts: {len(balanta)}   rows: F10={sum(1 for k in acc if k[0]=='F10')} F20={sum(1 for k in acc if k[0]=='F20')}")
    mat = [b for b in unrouted if abs(b['SFD'])+abs(b['SFC'])>0.5]
    print(f"     material unmapped: {len(mat)}")
    for b in mat[:20]:
        print(f"        {b['cont']:>8} {str(b['nume'])[:34]:34} D={b['SFD']:.0f} C={b['SFC']:.0f}")
    print(f"     split accounts (see SPLITS sheet): {len(splits)}")

if __name__ == '__main__':
    sys.exit(main())
