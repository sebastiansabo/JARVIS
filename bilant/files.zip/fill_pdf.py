#!/usr/bin/env python3
"""
fill_pdf.py  —  Stage 2 of the bilant pipeline.

Reads:  the ANAF XFA PDF + the workpaper .xlsx produced by build_workpaper.py
Writes: a NEW PDF with the F10/F20 datasets values injected, every other packet
        (template, config, form, localeSet, ...) preserved byte-for-byte, and
        NeedsRendering kept true so ANAF/Adobe recompute the TOTAL rows and
        appearances on open. The original file is never modified.

Value source per row: OVERRIDE_* column if present, else the computed column.
Only LEAF (non-total) rows are written; total rows are left for the form's own
calc scripts. F10 is filled inside its nested container (104<->104, fully
anchored). F20 is filled inside a positional bracket (first R## .. next Table1),
which aligns 88<->88 with all named anchors matching.

Usage:
  python3 fill_pdf.py --pdf BILANT.pdf --workpaper workpaper.xlsx --out BILANT_filled.pdf
  add --verify to re-extract datasets and confirm written values
"""
import argparse, sys, re
import xml.etree.ElementTree as ET
import openpyxl
import bilant_core as bc

XFA_DATA_NS = bc.XFA_DATA_NS
# Preserve the canonical XFA prefix on re-serialization (else ET emits ns0:)
ET.register_namespace('xfa', XFA_DATA_NS)

def load_workpaper(path):
    """Return {'F10': {element: {'C1':val,'C2':val}}, 'F20': {...}}. OVERRIDE wins."""
    wb = openpyxl.load_workbook(path, data_only=True)
    out = {'F10': {}, 'F20': {}}
    for form in ('F10', 'F20'):
        ws = wb[form]
        hdr = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        idx = {h: i + 1 for i, h in enumerate(hdr) if h}
        e_col = idx['element']
        # column 4/5 = computed begin/end (or prior/current); 6/7 = overrides
        comp1, comp2 = 4, 5
        ov1 = idx.get('OVERRIDE_BEGIN', idx.get('OVERRIDE_PRIOR'))
        ov2 = idx.get('OVERRIDE_END',   idx.get('OVERRIDE_CURRENT'))
        flag_col = idx.get('flags')
        for r in range(2, ws.max_row + 1):
            el = ws.cell(r, e_col).value
            if not el:
                continue
            flags = (ws.cell(r, flag_col).value or '') if flag_col else ''
            if 'TOTAL-ROW' in flags:
                continue  # never write total rows; the form recomputes them
            def pick(ovc, compc):
                v = ws.cell(r, ovc).value if ovc else None
                if v is None or v == '':
                    v = ws.cell(r, compc).value
                if v is None or v == '':
                    return None
                try: return float(v)
                except: return None
            v1, v2 = pick(ov1, comp1), pick(ov2, comp2)
            cell = {}
            if v1 is not None: cell['C1'] = v1
            if v2 is not None: cell['C2'] = v2
            if cell:
                out[form][el] = cell
    return out

def f20_bracket_container(form1):
    """Build a synthetic container holding form1's F20 flat region
    (first R## child .. just before the next Table1). The child element
    objects are shared, so writing their .text mutates the real datasets tree."""
    children = list(form1)
    start = None
    for i, c in enumerate(children):
        if re.match(r'R\d+$', bc.local(c.tag)):
            start = i; break
    if start is None:
        return None
    end = len(children)
    for i in range(start, len(children)):
        if bc.local(children[i].tag) == 'Table1':
            end = i; break
    synth = ET.Element('F20_BRACKET')
    for c in children[start:end]:
        synth.append(c)
    return synth

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pdf', required=True)
    ap.add_argument('--workpaper', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--verify', action='store_true')
    ap.add_argument('--skip-f20', action='store_true',
                    help="fill only F10 (balance sheet); leave F20/P&L untouched")
    a = ap.parse_args()

    pdf, packets, order = bc.read_packets(a.pdf)
    secs = bc.parse_template(packets['template'])
    router, rows_index, section_for = bc.build_account_router(secs)
    values = load_workpaper(a.workpaper)

    ds_root = ET.fromstring(packets['datasets'])
    form1 = next(c for c in ds_root.iter() if bc.local(c.tag) == 'form1')

    reports = {}

    # ---- F10: nested container, fully anchored ----
    f10_container = bc._section_container(form1, section_for['F10'])
    if f10_container is None:
        print("[FATAL] F10 container not found in datasets"); return 2
    f10_tmpl = secs[section_for['F10']]
    reports['F10'] = bc.align_and_write(f10_container, f10_tmpl, values['F10'],
                                        period_cols=['C1', 'C2'])

    # ---- F20: positional bracket ----
    if not a.skip_f20:
        f20_container = f20_bracket_container(form1)
        if f20_container is None:
            print("[WARN] F20 region not found; skipping F20")
        else:
            f20_tmpl = secs[section_for['F20']]
            reports['F20'] = bc.align_and_write(f20_container, f20_tmpl, values['F20'],
                                                period_cols=['C1', 'C2'])

    # ---- serialise datasets back & write new PDF ----
    new_ds = ET.tostring(ds_root, encoding='utf-8', xml_declaration=False)
    # preserve the XFA datasets wrapper/processing-instruction header if present
    head = packets['datasets'][:200].decode('utf-8', 'replace')
    if head.lstrip().startswith('<?xml'):
        new_ds = b'<?xml version="1.0" encoding="UTF-8"?>\n' + new_ds
    bc.write_packets(pdf, {'datasets': new_ds})
    pdf.save(a.out)

    for form, rep in reports.items():
        nwrote = len(rep['written'])
        print(f"[ok] {form}: wrote {nwrote} cells, anchors checked {rep['anchors_checked']}"
              + (f", length {rep['length_mismatch']}" if 'length_mismatch' in rep else "")
              + (f", skipped(no node) {len(rep['skipped_no_node'])}" if rep['skipped_no_node'] else ""))
    print(f"[ok] filled PDF -> {a.out}")

    if a.verify:
        verify(a.out, values, section_for, secs)
    return 0

def verify(path, values, section_for, secs):
    pdf, packets, order = bc.read_packets(path)
    ds_root = ET.fromstring(packets['datasets'])
    form1 = next(c for c in ds_root.iter() if bc.local(c.tag) == 'form1')
    ok = bad = 0
    # F10
    c10 = bc._section_container(form1, section_for['F10'])
    rep = bc.align_and_write(c10, secs[section_for['F10']], {}, ['C1','C2'], dry_run=True)
    nodes = {n: row for n, row in zip([t['name'] for t in secs[section_for['F10']]],
                                      bc.collect_ordered_value_nodes(c10))}
    for el, cols in values['F10'].items():
        row = nodes.get(el)
        if not row: continue
        for col, want in cols.items():
            got = row['cols'].get(col)
            got = got.text if got is not None else None
            if got == bc.format_amount(want): ok += 1
            else: bad += 1
    print(f"[verify] F10 cells matching written values: ok={ok} mismatch={bad}")

if __name__ == '__main__':
    sys.exit(main())
